const fs=require('fs');const path=require('path');
const file=path.join(__dirname,'src','App.jsx');
let s=fs.readFileSync(file,'utf8');
const MARK='CARVALIMA_SHEETS_SYNC_HARDENING_V2';
if(s.includes(MARK)){console.log('Sheets sync hardening já aplicado.');process.exit(0);}

// O Script de sincronização do Google Sheets usa payload.token.
// Não usar tokenSeguranca aqui: esse campo pertence ao fluxo do Script Gmail.
s=s.replace(/tokenSeguranca:\s*config\.gasToken/g,'token: config.gasToken');

const toast="        showToast(`Sincronização concluída! ${result.created || 0} novas, ${result.updated || 0} atualizadas.`, 'success');";
if(s.includes(toast)&&!s.includes("Array.isArray(result.monitorias)")){
 s=s.replace(toast,[
 '        if (Array.isArray(result.monitorias)) {',
 '          for (const remoteMonitoria of result.monitorias) {',
 "            await StorageService.saveItem('monitorias', remoteMonitoria);",
 '          }',
 "          const atualizadas = await StorageService.get('monitorias');",
 "          setMonitorias(atualizadas.filter(m => !m.deleted).sort((a,b) => new Date(b.dataAtendimento || 0) - new Date(a.dataAtendimento || 0)));",
 '        }',toast].join('\n'));
}

s += '\n/* '+MARK+' */\n';
fs.writeFileSync(file,s,'utf8');
console.log('Sheets sync hardening V2 aplicado.');
