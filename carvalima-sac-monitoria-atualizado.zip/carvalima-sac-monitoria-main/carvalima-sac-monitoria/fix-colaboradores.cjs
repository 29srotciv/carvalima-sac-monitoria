const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, 'src', 'App.jsx');
let s = fs.readFileSync(file, 'utf8');
const MARK = 'CARVALIMA_COLABORADORES_V1';
if (s.includes(MARK)) { console.log('Colaboradores V1 já aplicados.'); process.exit(0); }
const imp = "import ColaboradoresView from './ColaboradoresView';";
if (!s.includes(imp)) s = s.replace("import React, { useState, useMemo, useEffect, useRef } from 'react';", "import React, { useState, useMemo, useEffect, useRef } from 'react';\n" + imp);
if (!s.includes('const abrirColaboradorMonitorias')) {
  s = s.replace("  const handleSave = async (monitoria) => {", "  const abrirColaboradorMonitorias = (nome) => {\n    setFilters(prev => ({ ...prev, colaborador: nome }));\n    setCurrentTab('monitorias');\n  };\n\n  const handleSave = async (monitoria) => {");
}
if (!s.includes("currentTab === 'colaboradores'")) {
  const nav = "          <SidebarButton active={currentTab === 'monitorias'} onClick={() => { setCurrentTab('monitorias'); setMonitoriaEditando(null); }} icon={<Icons.Monitorias />} label=\"Monitorias\" expanded={sidebarExpanded} />";
  s = s.replace(nav, nav + "\n          <SidebarButton active={currentTab === 'colaboradores'} onClick={() => { setCurrentTab('colaboradores'); setMonitoriaEditando(null); setRascunhoEditando(null); }} icon={<Icons.CheckSquare />} label=\"Colaboradores\" expanded={sidebarExpanded} />");
  const render = "        {currentTab === 'monitorias' && <TabelasView monitorias={monitorias} unidades={unidades} darkMode={darkMode} onEdit={(m) => {setMonitoriaEditando(m); setCurrentTab('nova');}} onDelete={handleDelete} onViewDetail={setMonitoriaDetalhe} showToast={showToast} filters={filters} setFilters={setFilters} />}";
  s = s.replace(render, render + "\n        {currentTab === 'colaboradores' && <ColaboradoresView monitorias={monitorias} colaboradores={colaboradores} darkMode={darkMode} onNewMonitoria={abrirNovaMonitoria} onViewMonitorias={abrirColaboradorMonitorias} />}");
}
s += `\n/* ${MARK} */\n`;
fs.writeFileSync(file, s, 'utf8');
console.log('Colaboradores V1 aplicado.');
