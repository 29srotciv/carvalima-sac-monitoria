import React, { useMemo, useState } from 'react';

const norm = (v = '') => String(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toUpperCase();
const scoreOf = (m) => Math.max(0, Math.min(10, Number(m?.nota) || 0));
const dateOf = (m) => String(m?.dataAtendimento || m?.data || '').slice(0, 10);
const fmt = (n, d = 1) => Number(n || 0).toFixed(d);
const statusOf = (avg) => avg >= 9 ? 'Conforme' : avg >= 7 ? 'Em Atenção' : 'Crítico';

const STATUS_STYLE = {
  'Conforme': 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  'Em Atenção': 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  'Crítico': 'bg-rose-500/10 text-rose-600 border-rose-500/20'
};

export default function ColaboradoresView({ monitorias = [], colaboradores = [], darkMode = false, onNewMonitoria, onViewMonitorias }) {
  const [busca, setBusca] = useState('');
  const [departamento, setDepartamento] = useState('TODOS');
  const [status, setStatus] = useState('TODOS');
  const [minMonitorias, setMinMonitorias] = useState('');
  const [selecionado, setSelecionado] = useState(null);

  const dados = useMemo(() => {
    const map = new Map();
    monitorias.filter(m => !m?.deleted && String(m?.agente || '').trim()).forEach(m => {
      const nome = String(m.agente).trim();
      const key = norm(nome);
      if (!map.has(key)) map.set(key, { nome, departamento: m.departamento || 'Não informado', unidade: m.unidade || '—', total: 0, soma: 0, conformes: 0, criticos: 0, datas: [] });
      const x = map.get(key);
      x.total += 1;
      x.soma += scoreOf(m);
      if (scoreOf(m) >= 9) x.conformes += 1;
      if (scoreOf(m) < 7) x.criticos += 1;
      if (dateOf(m)) x.datas.push(dateOf(m));
      if ((!x.departamento || x.departamento === 'Não informado') && m.departamento) x.departamento = m.departamento;
      if ((!x.unidade || x.unidade === '—') && m.unidade) x.unidade = m.unidade;
    });

    // Colaboradores cadastrados sem monitoria continuam visíveis, mas com volume 0.
    colaboradores.filter(c => !c?.deleted && String(c?.nome || '').trim()).forEach(c => {
      const nome = String(c.nome).trim();
      const key = norm(nome);
      if (!map.has(key)) map.set(key, { nome, departamento: c.departamento || 'Não informado', unidade: c.unidade || '—', total: 0, soma: 0, conformes: 0, criticos: 0, datas: [] });
    });

    return Array.from(map.values()).map(x => ({
      ...x,
      media: x.total ? x.soma / x.total : 0,
      conformidade: x.total ? x.conformes / x.total * 100 : 0,
      ultima: x.datas.sort().at(-1) || '—',
      status: x.total ? statusOf(x.soma / x.total) : 'Sem monitoria'
    }));
  }, [monitorias, colaboradores]);

  const departamentos = useMemo(() => Array.from(new Set(dados.map(x => x.departamento).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'pt-BR')), [dados]);
  const filtrados = useMemo(() => {
    const q = norm(busca);
    return dados
      .filter(x => !q || norm(`${x.nome} ${x.departamento} ${x.unidade}`).includes(q))
      .filter(x => departamento === 'TODOS' || x.departamento === departamento)
      .filter(x => status === 'TODOS' || x.status === status)
      .filter(x => minMonitorias === '' || x.total >= Number(minMonitorias))
      .sort((a, b) => b.total - a.total || b.media - a.media || a.nome.localeCompare(b.nome, 'pt-BR'));
  }, [dados, busca, departamento, status, minMonitorias]);

  const totalMonitorias = monitorias.filter(m => !m?.deleted).length;
  const comMonitoria = dados.filter(x => x.total > 0).length;
  const mediaGeral = comMonitoria ? dados.filter(x => x.total > 0).reduce((s, x) => s + x.media, 0) / comMonitoria : 0;
  const top = filtrados[0];
  const selecionadoMonitorias = selecionado ? monitorias.filter(m => !m?.deleted && norm(m.agente) === norm(selecionado.nome)).sort((a, b) => dateOf(b).localeCompare(dateOf(a))) : [];

  const card = `rounded-2xl border ${darkMode ? 'bg-[#111A22] border-[#24313B]' : 'bg-white border-slate-200'} shadow-sm`;
  const input = `${darkMode ? 'bg-[#0B1117] border-[#24313B] text-white' : 'bg-slate-50 border-slate-200 text-slate-900'} border rounded-xl px-3 py-2.5 text-xs outline-none focus:ring-2 focus:ring-blue-500/20`;

  return (
    <div className={`flex-1 overflow-y-auto ${darkMode ? 'bg-[#0B1117] text-white' : 'bg-[#F4F7F9] text-slate-900'}`}>
      <div className="max-w-[1600px] mx-auto p-5 md:p-8 xl:p-10 space-y-6">
        <header className="flex flex-col xl:flex-row xl:items-end justify-between gap-4">
          <div>
            <span className="text-[9px] font-black uppercase tracking-[.22em] text-blue-500">Gestão de pessoas • qualidade SAC</span>
            <h1 className="text-3xl md:text-4xl font-black tracking-tight mt-2">Colaboradores</h1>
            <p className="text-sm text-slate-500 mt-1">Acompanhe quem já foi monitorado, o volume de avaliações e a qualidade média.</p>
          </div>
          <button onClick={onNewMonitoria} className="px-5 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-black shadow-lg">+ Nova monitoria</button>
        </header>

        <section className="grid grid-cols-2 xl:grid-cols-4 gap-3">
          <div className={`${card} p-4`}><span className="text-[9px] uppercase font-black text-slate-400">Colaboradores monitorados</span><b className="block text-2xl mt-2">{comMonitoria}</b><span className="text-[10px] text-slate-400">com pelo menos 1 monitoria</span></div>
          <div className={`${card} p-4`}><span className="text-[9px] uppercase font-black text-slate-400">Monitorias</span><b className="block text-2xl mt-2 text-blue-500">{totalMonitorias}</b><span className="text-[10px] text-slate-400">base atual</span></div>
          <div className={`${card} p-4`}><span className="text-[9px] uppercase font-black text-slate-400">Média por colaborador</span><b className="block text-2xl mt-2">{fmt(mediaGeral)}</b><span className="text-[10px] text-slate-400">média das notas médias</span></div>
          <div className={`${card} p-4`}><span className="text-[9px] uppercase font-black text-slate-400">Maior volume</span><b className="block text-lg mt-2 truncate">{top?.nome || '—'}</b><span className="text-[10px] text-slate-400">{top ? `${top.total} monitorias` : 'sem dados'}</span></div>
        </section>

        <section className={`${card} p-4`}>
          <div className="flex items-center gap-2 mb-3"><span className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-500 grid place-items-center font-black">⌕</span><div><b className="text-sm">Filtros</b><p className="text-[10px] text-slate-400">Refine a lista sem alterar os filtros do Dashboard.</p></div></div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
            <input className={input} value={busca} onChange={e => setBusca(e.target.value)} placeholder="Buscar colaborador, unidade..." />
            <select className={input} value={departamento} onChange={e => setDepartamento(e.target.value)}><option value="TODOS">Todos os departamentos</option>{departamentos.map(x => <option key={x}>{x}</option>)}</select>
            <select className={input} value={status} onChange={e => setStatus(e.target.value)}><option value="TODOS">Todos os status</option><option>Conforme</option><option>Em Atenção</option><option>Crítico</option><option>Sem monitoria</option></select>
            <input className={input} type="number" min="0" value={minMonitorias} onChange={e => setMinMonitorias(e.target.value)} placeholder="Mín. de monitorias" />
          </div>
        </section>

        <section className={`${card} overflow-hidden`}>
          <div className="px-5 py-4 border-b border-slate-200 dark:border-[#24313B] flex items-center justify-between gap-3"><div><b className="text-sm">Lista de colaboradores</b><p className="text-[10px] text-slate-400">{filtrados.length} pessoa(s) na visão atual</p></div><span className="text-[10px] font-black text-slate-400">Ordenado por volume</span></div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[820px]">
              <thead><tr className={`${darkMode ? 'bg-[#0B1117] text-slate-400' : 'bg-slate-50 text-slate-500'} text-[9px] uppercase tracking-wider`}><th className="px-5 py-3">Colaborador</th><th className="px-4 py-3">Departamento</th><th className="px-4 py-3">Unidade</th><th className="px-4 py-3 text-center">Monitorias</th><th className="px-4 py-3 text-center">Média</th><th className="px-4 py-3 text-center">Conformidade</th><th className="px-4 py-3">Última</th><th className="px-4 py-3">Status</th></tr></thead>
              <tbody className="divide-y divide-slate-100 dark:divide-[#24313B]">
                {filtrados.length === 0 ? <tr><td colSpan="8" className="py-16 text-center text-slate-400">Nenhum colaborador encontrado com os filtros atuais.</td></tr> : filtrados.map((x, i) => (
                  <tr key={norm(x.nome)} onClick={() => setSelecionado(x)} className="hover:bg-blue-500/[.04] cursor-pointer transition-colors">
                    <td className="px-5 py-3"><div className="flex items-center gap-3"><span className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-500 grid place-items-center font-black text-[10px]">{i + 1}</span><div><b className="block text-xs">{x.nome}</b><span className="text-[9px] text-slate-400">Clique para abrir o histórico</span></div></div></td>
                    <td className="px-4 py-3 text-[10px] text-slate-500">{x.departamento}</td>
                    <td className="px-4 py-3 font-semibold">{x.unidade}</td>
                    <td className="px-4 py-3 text-center font-black">{x.total}</td>
                    <td className="px-4 py-3 text-center font-black">{x.total ? fmt(x.media) : '—'}</td>
                    <td className="px-4 py-3 text-center">{x.total ? `${fmt(x.conformidade, 0)}%` : '—'}</td>
                    <td className="px-4 py-3 text-[10px] text-slate-500">{x.ultima === '—' ? '—' : new Date(`${x.ultima}T12:00:00`).toLocaleDateString('pt-BR')}</td>
                    <td className="px-4 py-3"><span className={`inline-flex px-2 py-1 rounded-full border text-[9px] font-black ${STATUS_STYLE[x.status] || 'bg-slate-500/10 text-slate-500 border-slate-500/20'}`}>{x.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>

      {selecionado && <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4" onMouseDown={e => { if (e.target === e.currentTarget) setSelecionado(null); }}>
        <div className={`${darkMode ? 'bg-[#111A22] border-[#24313B] text-white' : 'bg-white border-slate-200 text-slate-900'} w-full max-w-4xl max-h-[88vh] overflow-hidden rounded-3xl border shadow-2xl`}>
          <div className="p-5 border-b border-slate-200 dark:border-[#24313B] flex items-center justify-between gap-3"><div><span className="text-[9px] uppercase font-black tracking-wider text-blue-500">Histórico do colaborador</span><h2 className="text-xl font-black mt-1">{selecionado.nome}</h2><p className="text-[10px] text-slate-400">{selecionado.departamento} • {selecionado.unidade}</p></div><button onClick={() => setSelecionado(null)} className="w-9 h-9 rounded-xl bg-slate-800 text-slate-300">×</button></div>
          <div className="p-5 overflow-y-auto max-h-[68vh] space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3"><div className={`${card} p-3`}><span className="text-[9px] text-slate-400">Monitorias</span><b className="block text-xl mt-1">{selecionado.total}</b></div><div className={`${card} p-3`}><span className="text-[9px] text-slate-400">Média</span><b className="block text-xl mt-1">{selecionado.total ? fmt(selecionado.media) : '—'}</b></div><div className={`${card} p-3`}><span className="text-[9px] text-slate-400">Conformidade</span><b className="block text-xl mt-1">{selecionado.total ? `${fmt(selecionado.conformidade, 0)}%` : '—'}</b></div><div className={`${card} p-3`}><span className="text-[9px] text-slate-400">Críticas</span><b className="block text-xl mt-1 text-rose-500">{selecionado.criticos}</b></div></div>
            {selecionadoMonitorias.length === 0 ? <div className="py-12 text-center text-slate-400 text-xs">Este colaborador ainda não possui monitorias registradas.</div> : <div className="space-y-2">{selecionadoMonitorias.map(m => <div key={m.id} className={`${darkMode ? 'bg-[#0B1117] border-[#24313B]' : 'bg-slate-50 border-slate-200'} border rounded-2xl p-3 flex items-center gap-3`}><b className={`w-10 h-10 rounded-xl grid place-items-center text-xs ${scoreOf(m) >= 9 ? 'bg-emerald-500/10 text-emerald-500' : scoreOf(m) >= 7 ? 'bg-amber-500/10 text-amber-500' : 'bg-rose-500/10 text-rose-500'}`}>{fmt(scoreOf(m))}</b><div className="flex-1 min-w-0"><b className="text-xs block truncate">{m.id || 'Monitoria'}</b><span className="text-[9px] text-slate-400">{dateOf(m) ? new Date(`${dateOf(m)}T12:00:00`).toLocaleDateString('pt-BR') : 'Sem data'} • {m.unidade || '—'} • {m.departamento || '—'}</span></div><span className="text-[9px] font-black uppercase text-slate-400">{m.status || statusOf(scoreOf(m))}</span></div>)}</div>}
          </div>
          <div className="p-4 border-t border-slate-200 dark:border-[#24313B] flex justify-end gap-2"><button onClick={() => { onViewMonitorias?.(selecionado.nome); setSelecionado(null); }} className="px-4 py-2.5 rounded-xl border text-xs font-black">Ver na aba Monitorias</button><button onClick={onNewMonitoria} className="px-4 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-black">Nova monitoria</button></div>
        </div>
      </div>}
    </div>
  );
}
